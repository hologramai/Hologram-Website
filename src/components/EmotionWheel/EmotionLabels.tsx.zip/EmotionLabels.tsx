import React from "react";
import { EmotionPair, LabelPosition } from "./types";
import { WHEEL_SIZE } from "./constants";

interface EmotionLabelsProps {
  emotionPairs: EmotionPair[];
  selectedEmotion: string | null;
  intensity: number;
}

const EmotionLabels: React.FC<EmotionLabelsProps> = ({
  emotionPairs,
  selectedEmotion,
  intensity
}) => {
  const centerOffset = WHEEL_SIZE / 2;
  const circleRadius = WHEEL_SIZE / 2;

  const getCustomLabelPosition = (emotion: EmotionPair, isPrimary: boolean): LabelPosition => {
    const angleRad = (emotion.angle * Math.PI) / 180;
    const labelHeight = 32;
    const labelPadding = 5; // Distance from circle edge
    
    // Base position on circle edge
    let x = Math.cos(angleRad) * circleRadius + centerOffset;
    let y = Math.sin(angleRad) * circleRadius + centerOffset;
    
    // Calculate offset from circle edge
    let offsetX = 0;
    let offsetY = 0;
    
    // Custom positioning based on emotion
    if (isPrimary) {
      switch(emotion.primary) {
        case "Affection":
          offsetY = -(labelHeight + labelPadding); // 5px above circle
          break;
        case "Tact":
          offsetX = labelHeight/2 + labelPadding; // Well positioned
          break;
        case "Gentleness":
          offsetY = labelHeight/2 + labelPadding + 10; // Move up more
          break;
        case "Independence":
          offsetY = labelHeight/2 + labelPadding; // 5px below circle (matching Affection)
          break;
        case "Bluntness":
          offsetX = -(labelHeight/2 + labelPadding); // Keep well positioned
          break;
        case "Sass":
          offsetY = -(labelHeight/2 + labelPadding + 10); // Move down from current position
          break;
      }
    }
    
    // Apply offset based on angle
    const normalX = Math.cos(angleRad);
    const normalY = Math.sin(angleRad);
    
    x += normalX * offsetX;
    y += normalY * offsetY;
    
    return { x, y };
  };

  // Only render the 6 main emotions, no duplicates
  const mainEmotions = emotionPairs.filter(emotion => 
    ["gentleness", "independence", "bluntness", "sass", "affection", "tact"].includes(emotion.id)
  );

  return (
    <>
      {mainEmotions.map((emotion) => {
        const primaryPos = getCustomLabelPosition(emotion, true);
        
        return (
          <div key={emotion.id}>
            {/* Primary emotion label */}
            <div
              className="absolute transform -translate-x-1/2 -translate-y-1/2 pointer-events-none"
              style={{
                left: `${primaryPos.x}px`,
                top: `${primaryPos.y}px`,
              }}
            >
              <div
                className={`text-sm font-bold text-white bg-gray-700 px-3 py-1.5 rounded-lg whitespace-nowrap ${
                  selectedEmotion === emotion.id && intensity > 50 ? 'ring-2 ring-white scale-110 bg-gray-900' : ''
                }`}
                style={{ transition: 'all 0.2s ease' }}
              >
                {emotion.primary}
              </div>
            </div>
          </div>
        );
      })}
    </>
  );
};

export default EmotionLabels;